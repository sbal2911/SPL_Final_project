﻿open System

// Define a struct
[<Struct>]
type Point =
    val A: int
    val B: int
    new(a, b) = { A = a+10; B = b+20 }

[<EntryPoint>]
let main argv =

    // ---------------- DATA STRUCTURES ----------------
    // 1. Array of elements
    let Arr_of_elements = [| 41; 99; 30; 44; 57 |]
    printfn "Array of numbers: %A" Arr_of_elements

    // 2. List of elements
    let list_of_elements = [11.2; 23.9; 46.5; 40.5; 55.6]
    printfn "List of numbers: %A" list_of_elements

    // 3. Struct of Variables
    let struct_var = Point(20, 7)
    printfn "Structure example: A = %d, B = %d" struct_var.A struct_var.B

    // ---------------- CONTROL STRUCTURES ----------------
    // 1. For loop
    printfn "Showcasing For loop over array of elements:"
    for i in 0 .. Arr_of_elements.Length - 1 do
        printfn "Array of numbers[%d] = %d" i Arr_of_elements.[i]

    // 2. If-Else
    printfn "Showcasing If-Else functionality on list of elements:"
    for element in list_of_elements do
        if element > 46.4 then
            printfn "%f is greater than 46.4" element
        else
            printfn "%f is less than or equal to 46.4" element

    0  // successful execution
