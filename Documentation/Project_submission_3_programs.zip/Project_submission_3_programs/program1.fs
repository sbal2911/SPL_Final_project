﻿open System

[<EntryPoint>]
let main argv =

    // ---------------- INT ----------------
    let intnum1 = -20
    let intnum2 = 96
    let absValue = Math.Abs(intnum1)            // Built-in method 1: absolute value (manipulates data)
    let maxValue = Math.Max(intnum1, intnum2)      // Built-in method 2: maximum (manipulates data)
    printfn "Data manipulation for Int: Abs(%d) = %d, Maximum(%d, %d) = %d" intnum1 absValue intnum1 intnum2 maxValue

    // ---------------- DOUBLE ----------------
    let doublenum1 = 4.56554
    let doublenum2 = 8.65647
    let rounded = Math.Round(doublenum1, 2)     // Built-in method 1: round to 2 decimals
    let sqrtValue = Math.Sqrt(doublenum2)       // Built-in method 2: square root
    printfn "Data manipulation for Double: Round off(%.5f) = %.2f, Square root(%.5f) = %.5f" doublenum1 rounded doublenum2 sqrtValue

    // ---------------- STRING ----------------
    let exampleString = "Survey of Programming Languages"
    let exchangedString = exampleString.Replace("Languages", "F#") // Built-in method 1: replace substring
    let capsString = exampleString.ToUpper()                 // Built-in method 2: convert to uppercase
    printfn "Data manipulation for String: Replaced String = %s, Uppercase String = %s" exchangedString capsString

    // ---------------- BOOL ----------------
    let boolX = true
    let boolY = false
    let notX = not boolX                // Built-in method 1: logical NOT
    let andXY = boolX && boolY          // Built-in method 2: logical AND
    printfn "Data manipulation for Boolean: NOT %b = %b, %b AND %b = %b" boolX notX boolX boolY andXY

    0       //successful execution
