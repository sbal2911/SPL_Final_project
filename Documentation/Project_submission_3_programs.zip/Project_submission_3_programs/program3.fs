﻿open System

[<EntryPoint>]
let main argv =
    let num = 10
    let deno = 0  // Example for DivideByZeroException

    try
        let outcome = num / deno
        printfn "Final: %d" outcome
    with
    | :? DivideByZeroException ->
        printfn "Number cannot be divided by zero!"
    | ex ->
        printfn "Unknown error occurred!: %s" ex.Message

    0     //successful execution
